function ErrorMessage({children}){
    return (
    <span>{children}</span>
    );
};

export default ErrorMessage;